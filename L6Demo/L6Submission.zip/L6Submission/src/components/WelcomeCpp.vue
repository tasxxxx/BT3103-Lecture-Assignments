<template>
    <h1>Welcome to the CPP</h1>
</template>

<script>
    export default {

    }
</script>

<style scoped>
    h1 {
        background-color: rgb(129, 184, 99);
        /* display: inline-block; */
        text-align: center;
    }
</style>